# Python

The python local-interchain interaction client / driver.

## Running

```bash
cd python

# or setup your own virtualenv
pip install -r requirements.txt --break-system-packages

local-ic start juno_ibc

python3 api_test.py
```