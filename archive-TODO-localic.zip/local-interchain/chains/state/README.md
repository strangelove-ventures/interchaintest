
## avs-and-eigenlayer-deployed-anvil-state.json
- <https://github.com/mangata-finance/eigen-layer-monorepo/blob/main/tests/integration/avs-and-eigenlayer-deployed-anvil-state.json>